// EIGE: проверка Telegram и работа только со своей анкетой.
const allowedOrigin = 'https://cute-phoenix-415a68.netlify.app';
const encoder = new TextEncoder();

Deno.serve(async (req) => {
  const origin = req.headers.get('origin');
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': allowedOrigin,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'content-type, apikey, authorization, x-client-info',
    'Vary': 'Origin',
    'Cache-Control': 'no-store'
  };
  const reply = (data, status = 200) =>
    new Response(JSON.stringify(data), { status, headers });

  if (origin && origin !== allowedOrigin) return reply({ error: 'Origin not allowed' }, 403);
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers });
  if (req.method !== 'POST') return reply({ error: 'Method not allowed' }, 405);

  try {
    const token = Deno.env.get('TELEGRAM_BOT_TOKEN');
    if (!token) return reply({ error: 'Server configuration error' }, 500);

    const raw = await req.text();
    if (raw.length > 98304) return reply({ error: 'Request too large' }, 413);
    const body = JSON.parse(raw);
    const initData = body?.initData;
    if (typeof initData !== 'string' || initData.length > 8192) {
      return reply({ error: 'Invalid Telegram data' }, 401);
    }

    const params = new URLSearchParams(initData);
    const entries = [...params.entries()];
    if (new Set(entries.map(([key]) => key)).size !== entries.length) {
      return reply({ error: 'Invalid Telegram data' }, 401);
    }
    const hash = params.get('hash');
    const authDate = params.get('auth_date');
    if (!hash || !/^[a-fA-F0-9]{64}$/.test(hash) || !authDate || !/^\d+$/.test(authDate)) {
      return reply({ error: 'Invalid Telegram data' }, 401);
    }
    const age = Math.floor(Date.now() / 1000) - Number(authDate);
    if (age < -60 || age > 86400) return reply({ error: 'Telegram data expired' }, 401);

    params.delete('hash');
    const dataCheckString = [...params.entries()]
      .sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)
      .map(([key, value]) => `${key}=${value}`)
      .join('\n');

    const baseKey = await crypto.subtle.importKey(
      'raw', encoder.encode('WebAppData'), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
    );
    const secret = await crypto.subtle.sign('HMAC', baseKey, encoder.encode(token));
    const hmacKey = await crypto.subtle.importKey(
      'raw', secret, { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']
    );
    const hashBytes = Uint8Array.from(hash.match(/.{2}/g) || [], hex => parseInt(hex, 16));
    const valid = await crypto.subtle.verify('HMAC', hmacKey, hashBytes, encoder.encode(dataCheckString));
    if (!valid) return reply({ error: 'Invalid Telegram data' }, 401);

    const user = JSON.parse(params.get('user') || 'null');
    if (!user || !Number.isSafeInteger(user.id) || user.id <= 0) {
      return reply({ error: 'Invalid Telegram user' }, 401);
    }
    const action = body.action || 'check';
    if (action === 'check') {
      return reply({ ok: true, user: { id: user.id, first_name: String(user.first_name || '').slice(0, 100) } });
    }
    if (!['get_profile', 'save_profile', 'list_profiles', 'set_visibility', 'set_status', 'list_projects', 'create_project', 'apply_project', 'project_requests', 'decide_request', 'withdraw_request', 'project_chat_list', 'project_chat_send', 'list_my_projects', 'edit_project', 'delete_project'].includes(action)) {
      return reply({ error: 'Unknown action' }, 400);
    }

    // Only the server holds the privileged key. Never trust an ID from the browser.
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    if (!serviceKey || !supabaseUrl) return reply({ error: 'Server configuration error' }, 500);
    const baseUrl = supabaseUrl + '/rest/v1/eige_profiles';
    const databaseHeaders = {
      'apikey': serviceKey,
      'Authorization': 'Bearer ' + serviceKey,
      'Content-Type': 'application/json',
    };
    if (['list_projects', 'create_project', 'apply_project', 'project_requests', 'decide_request', 'withdraw_request', 'project_chat_list', 'project_chat_send', 'list_my_projects', 'edit_project', 'delete_project'].includes(action)) {
      const uuid = (v) => typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
      const headers = databaseHeaders;
      const rest = supabaseUrl + '/rest/v1/';
      const mine = await fetch(baseUrl + '?telegram_id=eq.' + encodeURIComponent(String(user.id)) + '&select=id&limit=1', { headers });
      if (!mine.ok) return reply({error:'Database error'}, 502);
      const actor = (await mine.json())[0];
      if (!actor || !uuid(actor.id)) return reply({error:'Profile not found'}, 404);
      const validAvatar = v => v === null || v === '' || (typeof v === 'string' && v.length <= 30000 && /^data:image\/jpeg;base64,\/9j\/[A-Za-z0-9+/]+={0,2}$/.test(v));
      const projects = rest + 'eige_projects';
      const requests = rest + 'eige_requests';
      // Notifications are best effort: Telegram may reject them if the user did not start the bot.
      async function notifyProfiles(profileIds, text) {
        try {
          const ids = [...new Set(profileIds.filter(id => uuid(id) && id !== actor.id))];
          if (!ids.length) return;
          for (let start = 0; start < ids.length; start += 100) {
            const slice = ids.slice(start, start + 100);
            const r = await fetch(baseUrl + '?id=in.(' + slice.join(',') + ')&select=telegram_id', {headers});
            if (!r.ok) continue;
            const recipients = await r.json();
            for (let j = 0; j < recipients.length; j += 20) {
              await Promise.all(recipients.slice(j,j+20).map(async recipient => {
                if (!Number.isSafeInteger(recipient.telegram_id) || recipient.telegram_id <= 0 || recipient.telegram_id === user.id) return;
                try {
                  await fetch('https://api.telegram.org/bot' + token + '/sendMessage', {
                    method:'POST', headers:{'Content-Type':'application/json'},
                    body:JSON.stringify({chat_id:recipient.telegram_id,text,disable_notification:false}),
                    signal:AbortSignal.timeout(3000)
                  });
                } catch (_) { /* Do not disclose tokens or make the completed action fail. */ }
              }));
            }
          }
        } catch (_) { /* Delivery failures do not roll back the underlying event. */ }
      }
      const safeTitle = value => typeof value === 'string' ? value.replace(/[\u0000-\u001f\u007f]/g,' ').slice(0,70) : 'проект';

      if (action === 'list_projects') {
        const offset = Number.isSafeInteger(body.offset) && body.offset >= 0 && body.offset <= 100000 ? body.offset : 0;
        const r = await fetch(projects + '?select=id,owner_id,title,category,description,city,avatar_data&order=created_at.desc&limit=100&offset=' + offset, {headers});
        if (!r.ok) return reply({error:'Database error'}, 502);
        const items = await r.json();
        const q = await fetch(requests + '?sender_id=eq.' + actor.id + '&project_id=not.is.null&select=project_id,status&limit=1000', {headers});
        if (!q.ok) return reply({error:'Database error'}, 502);
        const ownRequests = await q.json();
        return reply({ok:true, projects:items.map(p => ({id:p.id,title:p.title,category:p.category,description:p.description,city:p.city,avatar_data:p.avatar_data,is_owner:p.owner_id===actor.id,my_request_status:ownRequests.find(x => x.project_id===p.id)?.status || null}))});
      }
      if (action === 'list_my_projects') {
        const offset = Number.isSafeInteger(body.offset) && body.offset >= 0 && body.offset <= 100000 ? body.offset : 0;
        const r = await fetch(projects + '?owner_id=eq.' + actor.id + '&select=id,title,category,description,city,avatar_data&order=created_at.desc&limit=100&offset=' + offset, {headers});
        if (!r.ok) return reply({error:'Database error'}, 502);
        const items = await r.json();
        return reply({ok:true, projects:items.map(p => ({...p,is_owner:true}))});
      }
      if (action === 'create_project') {
        const v = body.project;
        if (!v || typeof v !== 'object' || Array.isArray(v)) return reply({error:'Invalid project'},400);
        const clean = {};
        for (const [field,max] of Object.entries({title:70,category:60,description:400,city:50})) {
          const value = v[field] ?? '';
          if (typeof value !== 'string' || value.length > max) return reply({error:'Invalid project'},400);
          clean[field] = value.trim();
        }
        if (!clean.title || !clean.description || !['Язык и культура','Экология','Предпринимательство','IT','Образование','Другое'].includes(clean.category)) return reply({error:'Invalid project'},400);
        if (!validAvatar(v.avatar_data ?? null)) return reply({error:'Invalid avatar'},400);
        clean.avatar_data = v.avatar_data || null;
        if (!uuid(body.request_id)) return reply({error:'Invalid request id'},400);
        const r = await fetch(projects + '?on_conflict=client_request_id', {method:'POST',headers:{...headers,'Prefer':'resolution=ignore-duplicates,return=minimal'},body:JSON.stringify({...clean,owner_id:actor.id,client_request_id:body.request_id})});
        if (!r.ok) return reply({error:'Database error'},502);
        const check = await fetch(projects + '?client_request_id=eq.' + body.request_id + '&owner_id=eq.' + actor.id + '&select=id&limit=1', {headers});
        if (!check.ok) return reply({error:'Database error'},502);
        if (!(await check.json()).length) return reply({error:'Invalid request id'},409);
        return reply({ok:true});
      }
      if (!uuid(body.project_id)) return reply({error:'Invalid project'},400);
      const pr = await fetch(projects + '?id=eq.' + body.project_id + '&select=id,owner_id,title&limit=1', {headers});
      if (!pr.ok) return reply({error:'Database error'},502);
      const project = (await pr.json())[0];
      if (!project) return reply({error:'Project not found'},404);
      if (action === 'project_chat_list' || action === 'project_chat_send') {
        if (Deno.env.get('EIGE_PROJECT_CHAT_ENABLED') !== 'true') return reply({error:'Chat disabled'},403);
        if (project.owner_id !== actor.id) {
          const member = await fetch(requests + '?project_id=eq.' + project.id + '&sender_id=eq.' + actor.id + '&status=eq.approved&select=id&limit=1', {headers});
          if (!member.ok) return reply({error:'Database error'},502);
          if (!(await member.json()).length) return reply({error:'Forbidden'},403);
        }
        const messages = rest + 'eige_project_messages';
        if (action === 'project_chat_send') {
          const text = typeof body.text === 'string' ? body.text.trim() : '';
          if (!text || text.length > 1000) return reply({error:'Invalid message'},400);
          const r = await fetch(messages, {method:'POST',headers:{...headers,'Prefer':'return=minimal'},body:JSON.stringify({project_id:project.id,sender_id:actor.id,body:text})});
          if (!r.ok) return reply({error:'Database error'},502);
          try {
            const members = await fetch(requests + '?project_id=eq.' + project.id + '&status=eq.approved&select=sender_id&limit=1000', {headers});
            if (members.ok) {
              const ids = (await members.json()).map(x => x.sender_id);
              await notifyProfiles([project.owner_id, ...ids], 'EIGE: новое сообщение в чате проекта «' + safeTitle(project.title) + '».');
            }
          } catch (_) { /* Message was already saved. */ }
          return reply({ok:true});
        }
        const r = await fetch(messages + '?project_id=eq.' + project.id + '&select=sender_id,body,created_at&order=created_at.desc&limit=100', {headers});
        if (!r.ok) return reply({error:'Database error'},502);
        const rows = await r.json();
        const ids = [...new Set(rows.map(x=>x.sender_id).filter(uuid))];
        let people = [];
        if (ids.length) {
          const rr = await fetch(baseUrl + '?id=in.(' + ids.join(',') + ')&select=id,name', {headers});
          if (!rr.ok) return reply({error:'Database error'},502);
          people = await rr.json();
        }
        return reply({ok:true,messages:rows.reverse().map(x=>({name:people.find(p=>p.id===x.sender_id)?.name || 'Участник',text:x.body,created_at:x.created_at}))});
      }
      if (action === 'apply_project') {
        if (project.owner_id === actor.id) return reply({error:'Own project'},400);
        const r = await fetch(requests, {method:'POST',headers:{...headers,'Prefer':'return=minimal'},body:JSON.stringify({project_id:project.id,sender_id:actor.id,status:'pending'})});
        if (r.status === 409) return reply({error:'Already applied'},409);
        if (!r.ok) return reply({error:'Database error'},502);
        await notifyProfiles([project.owner_id], 'EIGE: новая заявка на участие в проекте «' + safeTitle(project.title) + '». Откройте проект, чтобы её рассмотреть.');
        return reply({ok:true});
      }
      if (action === 'withdraw_request') {
        const query = '?project_id=eq.' + project.id + '&sender_id=eq.' + actor.id + '&status=eq.pending&select=id';
        const r = await fetch(requests + query, {method:'DELETE',headers:{...headers,'Prefer':'return=representation'}});
        if (!r.ok) return reply({error:'Database error'},502);
        const rows = await r.json();
        if (!rows.length) return reply({error:'Request not pending'},404);
        return reply({ok:true});
      }
      if (action === 'edit_project' || action === 'delete_project') {
        if (project.owner_id !== actor.id) return reply({error:'Forbidden'},403);
        if (action === 'delete_project') {
          const r = await fetch(rest + 'rpc/eige_delete_owned_project', {method:'POST',headers,body:JSON.stringify({p_project_id:project.id,p_owner_id:actor.id})});
          if (!r.ok) return reply({error:'Database error'},502);
          if (!(await r.json())) return reply({error:'Project not found'},404);
          return reply({ok:true});
        }
        const v = body.project;
        if (!v || typeof v !== 'object' || Array.isArray(v)) return reply({error:'Invalid project'},400);
        const clean = {};
        for (const [field,max] of Object.entries({title:70,category:60,description:400,city:50})) {
          const value=v[field] ?? '';
          if (typeof value !== 'string' || value.length > max) return reply({error:'Invalid project'},400);
          clean[field]=value.trim();
        }
        if (!clean.title || !clean.description || !['Язык и культура','Экология','Предпринимательство','IT','Образование','Другое'].includes(clean.category)) return reply({error:'Invalid project'},400);
        if ('avatar_data' in v) {
          if (!validAvatar(v.avatar_data)) return reply({error:'Invalid avatar'},400);
          clean.avatar_data = v.avatar_data || null;
        }
        const r = await fetch(projects + '?id=eq.' + project.id + '&owner_id=eq.' + actor.id + '&select=id', {method:'PATCH',headers:{...headers,'Prefer':'return=representation'},body:JSON.stringify(clean)});
        if (!r.ok) return reply({error:'Database error'},502);
        if (!(await r.json()).length) return reply({error:'Project not found'},404);
        return reply({ok:true});
      }
      if (project.owner_id !== actor.id) return reply({error:'Forbidden'},403);
      if (action === 'project_requests') {
        const r = await fetch(requests + '?project_id=eq.' + project.id + '&select=id,sender_id,status&order=created_at.desc&limit=100', {headers});
        if (!r.ok) return reply({error:'Database error'},502);
        const rows = await r.json();
        const ids = [...new Set(rows.map(x=>x.sender_id).filter(uuid))];
        let people = [];
        if (ids.length) {
          const rr = await fetch(baseUrl + '?id=in.(' + ids.join(',') + ')&select=id,name,role', {headers});
          if (!rr.ok) return reply({error:'Database error'},502);
          people = await rr.json();
        }
        return reply({ok:true, requests:rows.map(x=>({id:x.id,status:x.status,name:people.find(p=>p.id===x.sender_id)?.name || 'Участник',role:people.find(p=>p.id===x.sender_id)?.role || ''}))});
      }
      if (action === 'decide_request') {
        if (!uuid(body.request_id) || !['approved','rejected'].includes(body.decision)) return reply({error:'Invalid decision'},400);
        const query = '?id=eq.' + body.request_id + '&project_id=eq.' + project.id + '&status=eq.pending&select=id,status,sender_id';
        const r = await fetch(requests + query, {method:'PATCH',headers:{...headers,'Prefer':'return=representation'},body:JSON.stringify({status:body.decision})});
        if (!r.ok) return reply({error:'Database error'},502);
        const rows = await r.json();
        if (!rows.length) return reply({error:'Request not found or already decided'},404);
        await notifyProfiles([rows[0].sender_id], 'EIGE: вашу заявку в проект «' + safeTitle(project.title) + '» ' + (body.decision === 'approved' ? 'приняли' : 'отклонили') + '.');
        return reply({ok:true});
      }
    }
    const fields = 'name,role,city,profession,interests,about,goal,availability,is_listed,show_city,show_telegram,avatar_data,show_avatar';
    if (action === 'list_profiles') {
      // Only these fields are shared, and only for voluntarily listed profiles.
      const offset = Number.isSafeInteger(body.offset) && body.offset >= 0 && body.offset <= 100000 ? body.offset : 0;
      const query = '?is_listed=eq.true&telegram_id=neq.' + encodeURIComponent(String(user.id)) + '&select=id,name,role,profession,interests,availability,city,show_city,show_telegram,telegram_username,avatar_data,show_avatar&order=created_at.desc&limit=100&offset=' + offset;
      const result = await fetch(baseUrl + query, { headers: databaseHeaders });
      if (!result.ok) return reply({ error: 'Database error' }, 502);
      const rows = await result.json();
      return reply({ ok: true, profiles: rows.map(p => ({id:p.id,name:p.name,role:p.role,profession:p.profession,interests:p.interests,availability:p.availability,city:p.show_city ? p.city : null,avatar_data:p.show_avatar ? p.avatar_data : null,telegram_username:p.show_telegram && /^[A-Za-z0-9_]{5,32}$/.test(p.telegram_username || '') ? p.telegram_username : null})) });
    }
    if (action === 'set_status') {
      if (!['Не указан', 'Готов помочь', 'Работаю над проектом', 'Ищу команду', 'Занят'].includes(body.status)) return reply({ error: 'Invalid status' }, 400);
      const query = '?telegram_id=eq.' + encodeURIComponent(String(user.id)) + '&select=availability';
      const result = await fetch(baseUrl + query, {
        method: 'PATCH', headers: { ...databaseHeaders, 'Prefer': 'return=representation' },
        body: JSON.stringify({ availability: body.status })
      });
      if (!result.ok) return reply({ error: 'Database error' }, 502);
      const rows = await result.json();
      if (!rows.length) return reply({ error: 'Profile not found' }, 404);
      return reply({ ok: true, status: rows[0].availability });
    }
    if (action === 'set_visibility') {
      if (typeof body.visible !== 'boolean' || typeof body.show_city !== 'boolean' || typeof body.show_telegram !== 'boolean') return reply({ error: 'Invalid visibility' }, 400);
      const username = typeof user.username === 'string' && /^[A-Za-z0-9_]{5,32}$/.test(user.username) ? user.username : null;
      if (body.show_telegram && !username) return reply({ error: 'Telegram username missing' }, 400);
      const query = '?telegram_id=eq.' + encodeURIComponent(String(user.id)) + '&select=is_listed,show_city,show_telegram,show_avatar';
      const result = await fetch(baseUrl + query, {
        method: 'PATCH',
        headers: { ...databaseHeaders, 'Prefer': 'return=representation' },
        body: JSON.stringify({ is_listed: body.visible, show_city: body.show_city, show_telegram: body.show_telegram, telegram_username: body.show_telegram ? username : null, ...(typeof body.show_avatar === 'boolean' ? {show_avatar:body.show_avatar} : {}) })
      });
      if (!result.ok) return reply({ error: 'Database error' }, 502);
      const rows = await result.json();
      if (!rows.length) return reply({ error: 'Profile not found' }, 404);
      return reply({ ok: true, visible: rows[0].is_listed, show_city: rows[0].show_city, show_telegram: rows[0].show_telegram, show_avatar: rows[0].show_avatar });
    }
    if (action === 'get_profile') {
      const query = '?telegram_id=eq.' + encodeURIComponent(String(user.id)) + '&select=' + fields + '&limit=1';
      const result = await fetch(baseUrl + query, { headers: databaseHeaders });
      if (!result.ok) return reply({ error: 'Database error' }, 502);
      const rows = await result.json();
      return reply({ ok: true, profile: rows[0] || null });
    }
    const p = body.profile;
    if (!p || typeof p !== 'object' || Array.isArray(p)) return reply({ error: 'Invalid profile' }, 400);
    const limits = { name: 70, role: 50, city: 60, profession: 90, interests: 120, about: 400, goal: 140 };
    const clean = {};
    for (const [field, max] of Object.entries(limits)) {
      const value = p[field] ?? '';
      if (typeof value !== 'string' || value.length > max) return reply({ error: 'Invalid profile' }, 400);
      clean[field] = value.trim();
    }
    if (!clean.name || !['Ученик','Выпускник','Педагог','Специалист / предприниматель'].includes(clean.role)) {
      return reply({ error: 'Invalid profile' }, 400);
    }
    if ('avatar_data' in p) {
      const v = p.avatar_data;
      if (!(v === null || v === '' || (typeof v === 'string' && v.length <= 30000 && /^data:image\/jpeg;base64,\/9j\/[A-Za-z0-9+/]+={0,2}$/.test(v)))) return reply({error:'Invalid avatar'},400);
      clean.avatar_data = v || null;
    }
    const result = await fetch(baseUrl + '?on_conflict=telegram_id&select=' + fields, {
      method: 'POST',
      headers: { ...databaseHeaders, 'Prefer': 'resolution=merge-duplicates,return=representation' },
      body: JSON.stringify({ ...clean, telegram_id: user.id })
    });
    if (!result.ok) return reply({ error: 'Database error' }, 502);
    const rows = await result.json();
    return reply({ ok: true, profile: rows[0] });
  } catch (_) {
    return reply({ error: 'Invalid request' }, 400);
  }
});
